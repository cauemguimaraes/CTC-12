function e = H(p)

e = -sum(p .* log2(p));